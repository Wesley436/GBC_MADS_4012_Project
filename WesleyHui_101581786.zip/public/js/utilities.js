function stopPropagation(event) {
    event.stopPropagation();
}